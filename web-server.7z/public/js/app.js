console.log('Client side javascript file is loaded!')

const weatherForm = document.querySelector('form')
const search = document.querySelector('input')
const result = document.querySelector('result');
//result.appendChild(document.createTextNode('this fetch'));
var z = document.createElement('p'); // is a node
var c = document.createElement('p'); // is a node

weatherForm.addEventListener('submit', (e) => {
    e.preventDefault()

    const location = search.value
    //dom
    //have id add this data. querySelector 

    fetch('http://localhost:3000/weather?address=' + location).then((response) => {
        response.json().then((data) => {
            if (data.error) {
                console.log(data.error)
            } else {
                console.log(data.location)
                console.log(data.forecast)
                //append child
                z.innerHTML = 'result: '+data.location+' temp: '+data.forecast.temperature
                c.innerHTML = 'result: '+data.location+' temp: '+data.forecast.temperature
                //this code for reviewing basic domobject
                document.getElementById('result').appendChild(z);
                spec.appendChild(document.createTextNode('this fetch'))
                document.getElementById('spec').append(c);
                document.getElementById('result').className+="addclass";

            }
        })
    })
})
